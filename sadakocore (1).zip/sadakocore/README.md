# sadakocore

A Pen created on CodePen.

Original URL: [https://codepen.io/nanajulia-2008study/pen/ogjzPXv](https://codepen.io/nanajulia-2008study/pen/ogjzPXv).

